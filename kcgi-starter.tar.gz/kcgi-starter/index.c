/* $Id: index.c,v 1.5 2018/12/04 02:06:23 xvetrd Exp $ */

/* This is public domain. Attribute "xvetrd" if you want, I don't care */

#include <sys/types.h>		/* size_t, ssize_t */
#include <stdarg.h>		/* va_list */
#include <stddef.h>		/* NULL */
#include <stdint.h>		/* int64_t */
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <err.h>

#include <kcgi.h>
#include <kcgihtml.h>

#define TRUE 1
#define FALSE 0

extern char* __progname;

void
setup_kcgi(struct kreq * r, const char *const * page)
{
	if (KCGI_OK != khttp_parse(r, NULL, 0, page, 1, 0))
		exit(EXIT_FAILURE);
	khttp_head(r, kresps[KRESP_STATUS],
		   "%s", khttps[KHTTP_200]);
	khttp_head(r, kresps[KRESP_CONTENT_TYPE],
		   "%s;charset=utf-8", kmimetypes[KMIME_TEXT_HTML]);
	khttp_body(r);
}


void
k_simple_link(struct khtmlreq * r, char *href, char *text)
{
	khtml_attr(r, KELEM_A, KATTR_HREF, href, KATTR__MAX, NULL);
	khtml_puts(r, text);
	khtml_closeelem(r, 1); /* A */
}

void
setup_khtml(struct khtmlreq * hr, const char *title)
{
	khtml_attr(hr, KELEM_DOCTYPE, KATTR__MAX, NULL);
	khtml_closeelem(hr, 1);	/* DOCTYPE */

	khtml_attr(hr, KELEM_HTML, KATTR_LANG, "en", KATTR__MAX, NULL);
	khtml_elem(hr, KELEM_HEAD);
	khtml_elem(hr, KELEM_TITLE);
	khtml_puts(hr, title);
	khtml_closeelem(hr, 2);	/* TITLE, HEAD */
}

int 
main(void)
{
	/* pledge is important
	 * kcgi(1) man page tells us what we need. 
	 */
	if (pledge("stdio proc",NULL) == -1) {
		err(1,"pledge");
	}

	struct kreq 	r;
	struct khtmlreq hr;
	const char     *page = "testing page";

	setup_kcgi(&r, &page);

	khtml_open(&hr, &r, 0);
	setup_khtml(&hr, page);
	
	khtml_elem(&hr,KELEM_BODY);
	
	k_simple_link(&hr, "/index.cgi","home");

	khtml_putc(&hr,'\n');

	if (strcmp(__progname, "index.cgi") == 0)
	{
		khtml_elem(&hr,KELEM_H1);
		khtml_puts(&hr, "Under Construction.");
		khtml_closeelem(&hr,1); /* H1 */

		khtml_elem(&hr,KELEM_P);
		khtml_puts(&hr, "The good news is that kcgi/kcgihtml works.");

		khtml_elem(&hr,KELEM_BR); /* BR is already closed. */

		k_simple_link(&hr,"/about.cgi","about");
		khtml_closeelem(&hr,1); /* P */
	}
	else if (strcmp(__progname, "about.cgi") == 0)
	{
		khtml_elem(&hr,KELEM_P);

		khtml_puts(&hr, "This is my about page.");
		khtml_elem(&hr,KELEM_BR);
		khtml_puts(&hr, "It is a hardlink to the index page.");
		khtml_elem(&hr,KELEM_BR);
		khtml_puts(&hr, "(__progname is an awesome C feature)");
		khtml_closeelem(&hr,1); /* P */
	}
	else
	{
		khtml_elem(&hr,KELEM_P);
		khtml_puts(&hr, "Something has gone wrong. This shouldn't be here: ");
		khtml_puts(&hr, __progname);
		khtml_closeelem(&hr,1); /* P */
	}

	khtml_close(&hr); // ALL
	khttp_free(&r);
	return 0;
}
